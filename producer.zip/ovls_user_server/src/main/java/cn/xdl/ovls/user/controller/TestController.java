package cn.xdl.ovls.user.controller;

import cn.xdl.ovls.user.entity.ResponseResult;
import org.springframework.web.bind.annotation.*;

@RestController
public class TestController {
    @RequestMapping(value = "/testParameterBind")
    public ResponseResult testParameterBind(@RequestBody ResponseResult responseResult) {
        return responseResult;
    }
    @RequestMapping(value = "/test",method = RequestMethod.GET)
    public ResponseResult test() {
        ResponseResult responseResult = new ResponseResult();
        responseResult.setName("liubei");
        responseResult.setAge(30);
        return responseResult;
    }
}
