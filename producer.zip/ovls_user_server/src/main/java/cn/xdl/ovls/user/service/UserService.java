package cn.xdl.ovls.user.service;

import cn.xdl.ovls.user.entity.ResponseResult;

public interface UserService {
	
	public ResponseResult createToken(String name,String password);
	
	public ResponseResult checkToken(String token);
	
}
