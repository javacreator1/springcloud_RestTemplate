package cn.xdl.ovls;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@EnableDiscoveryClient//启用eureka服务查找和注册
@SpringBootApplication
public class UserServiceBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserServiceBootApplication.class, args);
	}

}
