package cn.xdl.ovls.user.entity;

import java.io.Serializable;

public class ResponseResult implements Serializable {
    String name;
    Integer age;

    @Override
    public String toString() {
        return "ResponseResult{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }
}
