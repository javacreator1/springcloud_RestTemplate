package cn.xdl.ovls.user.util;

import java.util.UUID;

public class TokenUtil {
	
	/**
	 * 生成一个令牌号
	 * @return 令牌号
	 */
	public static String generatorToken(int userId){
		UUID uuid = UUID.randomUUID();
		return uuid.toString()+"-"+userId;
	}
	
	public static void main(String[] args){
		System.out.println(generatorToken(12));
	}
}
