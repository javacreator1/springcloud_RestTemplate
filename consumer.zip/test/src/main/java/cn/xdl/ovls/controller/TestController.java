package cn.xdl.ovls.controller;

import cn.xdl.ovls.entity.ResponseResult;
import cn.xdl.ovls.remote.UserServiceRemote;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class TestController {
    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private UserServiceRemote userServiceRemote;

    @RequestMapping(value = "/testParameterBind")
    public ResponseResult testParameterBind(ResponseResult responseResult) {
        return userServiceRemote.getResult(responseResult);
    }
    @RequestMapping(value = "/testFeign",method = RequestMethod.POST)
    public ResponseResult testFeign(Integer age) {
        return userServiceRemote.getObject(age);
    }
    @RequestMapping(value = "/test",method = RequestMethod.GET)
    public ResponseResult test() {
        ResponseResult responseResult = restTemplate.getForObject("http://USERSERVER/test", ResponseResult.class);
        return responseResult;
    }

    @RequestMapping("/test1")
    public String test1() {
        return "success";
    }

}




