package cn.xdl.ovls.remote;

import cn.xdl.ovls.entity.ResponseResult;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name="USERSERVER")//对应哪个服务实例
public interface UserServiceRemote {

    //调用/user/token服务
    @RequestMapping(value="/test",method= RequestMethod.POST)
    public ResponseResult getObject(@RequestParam("age") Integer age);

    @RequestMapping(value="/testParameterBind",method= RequestMethod.POST)
    public ResponseResult getResult(@RequestBody ResponseResult responseResult);
}
